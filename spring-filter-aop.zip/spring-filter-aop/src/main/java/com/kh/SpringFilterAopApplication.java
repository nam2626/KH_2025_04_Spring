package com.kh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFilterAopApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringFilterAopApplication.class, args);
	}

}
