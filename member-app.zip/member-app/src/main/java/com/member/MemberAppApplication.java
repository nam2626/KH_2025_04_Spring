package com.member;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MemberAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MemberAppApplication.class, args);
	}

}
